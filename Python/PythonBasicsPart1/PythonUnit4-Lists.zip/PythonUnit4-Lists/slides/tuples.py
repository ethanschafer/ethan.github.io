myTuple = (255, 0, 89)

print "A tuple"
print myTuple
print

print "The data at index 2"
print myTuple[2]
print

print "Appending to a tuple"
myTuple.append(35)
