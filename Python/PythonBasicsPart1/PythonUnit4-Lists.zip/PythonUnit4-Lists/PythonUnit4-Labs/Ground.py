import pygame, random
from pygame.locals import *

def drawGround(window):
    # load all images into a list 
    
    
    # Create variables to keep track of where to
    # draw the grass
    
    
    # Outer loop runs as long as x is 
    # not past the right edge of the screen
      
        
        # Inner loop runs as long as y is 
        # not past the bottom edge of the screen

            # Use the y position to determine which tile to draw
            # Increase the y
        
            
        # Increase the x and reset the y

    pass
