# Space-Gataca
# You should download all the files into one folder and run Main.py, to play the game.
# https://bitbucket.org/pygame/pygame/downloads
