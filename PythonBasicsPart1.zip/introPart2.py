#---------------------variables----------------
#String
name = "Mr Remington"

#integer
grade = 99

#float
gpa = 3.98

#---------------------methods/functions--------------------

def changeStuff():
    name = "joe"
    grade = 78
    gpa = 3.2

def doStuff():
    print(name+" "+str(grade)+" "+str(gpa) )

#----------------calling methods-----------------
doStuff();


    
