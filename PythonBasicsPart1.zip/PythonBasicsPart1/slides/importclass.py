from Student import *

# Creates a Student
myStudent = Student("Xavier", 9, "History")

# prints the Student's name
print myStudent.getName()