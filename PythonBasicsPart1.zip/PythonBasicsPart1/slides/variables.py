# Example 1

grade = 86
student = "Bob"
theEnd = False

print "Example 1"
print "Grade is", str(grade)
print "Name is", student
print "theEnd is", theEnd


# Example 2

print "\n\nExample 2"
Name = "Tim"
name = raw_input("What is your name? ")
print "Name is", Name
print "Your name is", name



# Example 3

print "\n\nExample 3"
num = input("Pick a number: ")
print "Your number is", num