print "Example 1"
print "Comp Sci Rocks!"


print "\n\nExample 2"
print "Comp Sci"
print "Rocks!"


print "\n\nExample 3"
print "Comp Sci",
print "Rocks!"


print "\n\nExample 4"
print "Comp Sci \\Rocks!"
print "Comp Sci\tRocks!"