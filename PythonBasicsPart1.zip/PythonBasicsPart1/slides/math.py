# Math Examples

print "Example 1"
total = 3 + 4
product = 1.5 * 12
print "Total is", str(total)
print "Product is", str(product)


print "\n\nExample 2"
intDiv = 3 / 4
remainder = 3 % 4
decDiv = 3 / 4.0
print "Integer division is", str(intDiv)
print "Remainder is", str(remainder)
print "Decimal division is", str(decDiv)

print "\n\nExample 3"
num = 3
num *= 2
print num
