
# Fill in the trick1 method here
def trick1(num):
    
    # Double num
    
    # Add 6 to the answer
    
    # Divide the answer by 2
    
    # Subtract num from the answer
    
    # Return the final answer
    return 0


# Write your trick2 method here
# trick2 does the following:
# 1. Multiply the number by 3
# 2. Add 45 to the answer# 3. Multiple the answer by 2
# 4. Divide the answer by 6
# 5. Subtract your original number from the answer
