import pygame
from pygame.locals import *


# Create a class called Person


    
    # Create a constructor method that sets self.x to newX, 
    # self.y to newY and loads the image "dude.gif" into self.img
    
    
    
        

    # draw the image on the surface

    
    
    
        
    
    def moveLeft(self):
        # Change x so that the object can move left
        pass
    
    

    def moveRight(self):
        # Change x so that the object can move right
        pass
    
       

    def moveUp(self):
        # Change y so that the object can move up
        pass
    

    
    def moveDown(self):
        # Change y so that the object can move down
        pass
        