
# Get the user's name



# Get the user's age



# Get the current year



# Print the user's name and age



# Print the year the user was born
