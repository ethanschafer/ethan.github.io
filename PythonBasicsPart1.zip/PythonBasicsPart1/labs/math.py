# Get an integer for x from the user



# Get an integer for y from the user




# Get a decimal for z from the user





# Print the product of x and y





# Print the product of x, y, and z





# Print the remainder of x divided by 2
# Remember to use modulus (%) to get the remainder




# Print the remainder of y divided by 2




# Print the remainder of z divided by 2

