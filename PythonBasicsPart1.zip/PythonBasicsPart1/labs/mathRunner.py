from mathTricks import *


inst1 = "Math Trick 1\n\
        1. Pick a number less than 10\n\
        2. Double the number\n\
        3. Add 6 to the answer\n\
        4. Divide the answer by 2\n\
        5. Subtract your original number from the answer\n"

print inst1


# Get input for the first math trick
num = input("Enter a number less than 10: ")



# Call the trick1 method and print the result
print "Your answer is", str(trick1(num)), "\n\n"



inst2 = "Math Trick 2\n\
        1. Pick any number\n\
        2. Multiply the number by 3\n\
        3. Add 45 to the answer\n\
        4. Multiple the answer by 2\n\
        5. Divide the answer by 6\n\
        6. Subtract your original number from the answer\n"

print inst2


# Get input for the second math trick






# Call the trick2 method and print the result

